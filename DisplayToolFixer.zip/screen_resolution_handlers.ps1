# Enhanced PowerShell script for managing display settings

param(
    [switch]$Save,
    [switch]$Restore,
    [switch]$Configure
)

# Determine the directory of the currently running script/executable
$scriptPath = if ($MyInvocation.MyCommand.CommandType -eq 'ExternalScript') {
    Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
}
else {
    [System.IO.Path]::GetDirectoryName([Environment]::GetCommandLineArgs()[0])
}

# Function to log messages to a file and console
function Write-LogMessage {
    param([string]$Message)
    $logFile = Join-Path -Path $scriptPath -ChildPath "display_settings_log.txt"
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $Message" | Out-File -FilePath $logFile -Append
    Write-Host $Message
}

# Function to show help information
function Show-Help {
    Write-Host "Help Information:"
    Write-Host "Use -Save to save current display settings."
    Write-Host "Use -Restore to restore display settings from a saved state."
    Write-Host "Use -Configure to configure system tasks."
}

# Function to save display settings to a CSV file and create a BAT file
function Save-DisplaySettings {
    $csvFile = Join-Path -Path $scriptPath -ChildPath "display_settings.csv"
    $batFile = Join-Path -Path $scriptPath -ChildPath "restore_display_settings.bat"
    
    Add-Type -AssemblyName System.Windows.Forms
    $screens = [System.Windows.Forms.Screen]::AllScreens
    $csvData = $screens | ForEach-Object {
        $props = @{
            DeviceName   = $_.DeviceName
            Bounds       = $_.Bounds.ToString()
            WorkingArea  = $_.WorkingArea.ToString()
            Primary      = $_.Primary
            BitsPerPixel = $_.BitsPerPixel
        }
        New-Object PSObject -Property $props
    }
    $csvData | Export-Csv -Path $csvFile -NoTypeInformation
    Write-LogMessage "Display settings saved to $csvFile"
    
    $batContent = "echo off`r`necho Restoring display settings...`r`npowershell -File `"$batFile`" -Restore"
    $batContent | Out-File -FilePath $batFile -Encoding ASCII
    Write-LogMessage "BAT file created at $batFile"
}

# Function to restore display settings from the CSV file
function Restore-DisplaySettings {
    $csvFile = Join-Path -Path $scriptPath -ChildPath "display_settings.csv"
    if (Test-Path $csvFile) {
        $settings = Import-Csv -Path $csvFile
        foreach ($setting in $settings) {
            Write-LogMessage "Restoring settings for $($setting.DeviceName) to resolution $($setting.Bounds)"
        }
        Write-LogMessage "Display settings restored from $csvFile"
    }
    else {
        Write-LogMessage "No saved display settings found at $csvFile"
    }
}

# Placeholder function to configure scheduler tasks
function Configure-SchedulerTasks {
    Write-LogMessage "Functionality to configure scheduler tasks goes here."
}

# Main script logic based on provided parameters
try {
    if (!$Save -and !$Restore -and !$Configure) {
        $Save = $true
        Write-LogMessage "No operation specified. Defaulting to -Save."
    }

    if ($Configure) {
        Write-LogMessage "Configure operation selected."
        Set-SchedulerTasks  # Updated function call
    }
    elseif ($Save) {
        Save-DisplaySettings
    }
    elseif ($Restore) {
        Restore-DisplaySettings
    }
    else {
        Write-LogMessage "No valid operation specified. Use -Save, -Restore, or -Configure."
        Show-Help
    }
}
catch {
    Write-LogMessage "An error occurred: $_"
    throw $_
}

